'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useToast } from '@/hooks/use-toast'
import { useTestStore, type Test, type Question } from '@/store/testStore'
import { 
  Clock, 
  ChevronLeft, 
  ChevronRight, 
  Flag,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Send,
  Pause
} from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'

interface TestSolveProps {
  testId?: string
}

export function TestSolve({ testId }: TestSolveProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const { getTest, addAttempt } = useTestStore()
  
  // Get test ID from props or URL
  const currentTestId = testId || searchParams.get('testId') || ''
  
  // Get test data
  const [test, setTest] = useState<Test | null>(null)
  
  // Quiz state
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<string, number>>({})
  const [flaggedQuestions, setFlaggedQuestions] = useState<Set<string>>(new Set())
  const [timeLeft, setTimeLeft] = useState(0)
  const [isPaused, setIsPaused] = useState(false)
  const [showSubmitDialog, setShowSubmitDialog] = useState(false)
  const [showExitDialog, setShowExitDialog] = useState(false)
  const [testStarted, setTestStarted] = useState(false)
  const [showStartDialog, setShowStartDialog] = useState(true)

  // Load test data
  useEffect(() => {
    if (currentTestId) {
      const testData = getTest(currentTestId)
      if (testData) {
        setTest(testData)
        setTimeLeft((testData.timeLimit || testData.questions.length * 2) * 60)
      }
    }
  }, [currentTestId, getTest])

  // Timer
  useEffect(() => {
    if (!testStarted || isPaused || timeLeft <= 0) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleSubmit()
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [testStarted, isPaused])

  // Format time
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  // Start test
  const handleStart = () => {
    setShowStartDialog(false)
    setTestStarted(true)
    toast({
      title: 'Test boshlandi! 🎯',
      description: `Sizda ${formatTime(timeLeft)} vaqt bor`,
    })
  }

  // Answer question
  const handleAnswer = (questionId: string, answer: number) => {
    setAnswers((prev) => ({ ...prev, [questionId]: answer }))
  }

  // Flag question
  const toggleFlag = (questionId: string) => {
    setFlaggedQuestions((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(questionId)) {
        newSet.delete(questionId)
      } else {
        newSet.add(questionId)
      }
      return newSet
    })
  }

  // Navigate questions
  const goToQuestion = (index: number) => {
    if (test && index >= 0 && index < test.questions.length) {
      setCurrentQuestion(index)
    }
  }

  // Submit test
  const handleSubmit = useCallback(() => {
    if (!test) return

    // Calculate results
    let correctCount = 0
    test.questions.forEach((q) => {
      if (answers[q.id] === q.correctAnswer) {
        correctCount++
      }
    })

    const score = Math.round((correctCount / test.questions.length) * 100)
    const timeSpent = ((test.timeLimit || test.questions.length * 2) * 60) - timeLeft

    // Save attempt
    addAttempt({
      testId: test.id,
      testName: test.name,
      answers: Object.entries(answers).map(([questionId, answer]) => ({
        questionId,
        answer,
      })),
      score,
      correctCount,
      totalQuestions: test.questions.length,
      timeSpent,
    })

    // Navigate to results
    router.push(`/?view=results&testId=${test.id}&score=${score}&correct=${correctCount}&total=${test.questions.length}`)
  }, [test, answers, timeLeft, addAttempt, router])

  // Get question status
  const getQuestionStatus = (question: Question, index: number) => {
    const isAnswered = answers[question.id] !== undefined
    const isFlagged = flaggedQuestions.has(question.id)
    const isCurrent = index === currentQuestion

    if (isCurrent) return 'current'
    if (isFlagged) return 'flagged'
    if (isAnswered) return 'answered'
    return 'unanswered'
  }

  // Loading state
  if (!test) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Clock className="h-8 w-8 text-muted-foreground" />
          </div>
          <p className="text-muted-foreground">Test yuklanmoqda...</p>
        </div>
      </div>
    )
  }

  const currentQ = test.questions[currentQuestion]
  const answeredCount = Object.keys(answers).length
  const progress = (answeredCount / test.questions.length) * 100

  return (
    <div className="space-y-4 p-4 md:p-6 max-w-5xl mx-auto">
      {/* Start Dialog */}
      <Dialog open={showStartDialog} onOpenChange={setShowStartDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl">Testni boshlash</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="p-4 rounded-xl bg-muted/50 space-y-2">
              <h3 className="font-semibold text-lg">{test.name}</h3>
              {test.description && (
                <p className="text-sm text-muted-foreground">{test.description}</p>
              )}
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-center">
              <div className="p-3 rounded-xl bg-muted">
                <p className="text-2xl font-bold text-foreground">{test.questions.length}</p>
                <p className="text-xs text-muted-foreground">Savol</p>
              </div>
              <div className="p-3 rounded-xl bg-muted">
                <p className="text-2xl font-bold text-foreground">{formatTime(timeLeft)}</p>
                <p className="text-xs text-muted-foreground">Vaqt</p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/30">
              <div className="flex items-start gap-2">
                <AlertCircle className="h-5 w-5 text-yellow-500 shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-medium text-foreground">Diqqat!</p>
                  <p className="text-muted-foreground">
                    Testni boshlaganingizdan so&apos;ng vaqt hisoblanadi. Tayyor bo&apos;lsangiz boshlang.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => router.push('/?view=tests')}>
              Ortga
            </Button>
            <Button onClick={handleStart} className="gap-2">
              Testni boshlash
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Exit Dialog */}
      <Dialog open={showExitDialog} onOpenChange={setShowExitDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Testdan chiqish</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-muted-foreground">
              Haqiqatan ham testdan chiqmoqchimisiz? Javoblaringiz saqlanmaydi.
            </p>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowExitDialog(false)}>
              Davom etish
            </Button>
            <Button variant="destructive" onClick={() => router.push('/?view=tests')}>
              Chiqish
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Submit Dialog */}
      <Dialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Testni yakunlash</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="grid grid-cols-2 gap-4 text-center">
              <div className="p-3 rounded-xl bg-secondary/10 border border-secondary/30">
                <p className="text-2xl font-bold text-secondary">{answeredCount}</p>
                <p className="text-xs text-muted-foreground">Javob berilgan</p>
              </div>
              <div className="p-3 rounded-xl bg-muted">
                <p className="text-2xl font-bold text-foreground">{test.questions.length - answeredCount}</p>
                <p className="text-xs text-muted-foreground">Javobsiz</p>
              </div>
            </div>
            
            {test.questions.length - answeredCount > 0 && (
              <div className="p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/30">
                <p className="text-sm text-muted-foreground">
                  ⚠️ {test.questions.length - answeredCount} ta savolga javob berilmagan
                </p>
              </div>
            )}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowSubmitDialog(false)}>
              Tekshirish
            </Button>
            <Button onClick={handleSubmit} className="gap-2">
              <Send className="h-4 w-4" />
              Yakunlash
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-foreground">{test.name}</h1>
          <p className="text-sm text-muted-foreground">
            {currentQuestion + 1} / {test.questions.length} savol
          </p>
        </div>
        <div className="flex items-center gap-3">
          {/* Timer */}
          <div className={`flex items-center gap-2 px-4 py-2 rounded-xl ${
            timeLeft < 60 ? 'bg-destructive/10 text-destructive' : 'bg-muted'
          }`}>
            <Clock className="h-5 w-5" />
            <span className="font-mono font-bold text-lg">{formatTime(timeLeft)}</span>
          </div>
          {/* Pause */}
          <Button
            variant="outline"
            size="icon"
            onClick={() => setIsPaused(!isPaused)}
          >
            <Pause className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Progress */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Jarayon</span>
          <span className="font-medium">{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {/* Question Navigation */}
      <div className="flex gap-1 overflow-x-auto pb-2">
        {test.questions.map((q, index) => {
          const status = getQuestionStatus(q, index)
          return (
            <button
              key={q.id}
              onClick={() => goToQuestion(index)}
              className={`h-9 w-9 shrink-0 rounded-lg text-sm font-medium transition-all ${
                status === 'current'
                  ? 'bg-primary text-primary-foreground ring-2 ring-primary ring-offset-2'
                  : status === 'flagged'
                  ? 'bg-yellow-500 text-white'
                  : status === 'answered'
                  ? 'bg-secondary text-secondary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {index + 1}
            </button>
          )
        })}
      </div>

      {/* Question Card */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <Badge variant="outline" className="text-sm">
              {currentQuestion + 1}-savol
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => toggleFlag(currentQ.id)}
              className={`gap-2 ${flaggedQuestions.has(currentQ.id) ? 'text-yellow-500' : ''}`}
            >
              <Flag className={`h-4 w-4 ${flaggedQuestions.has(currentQ.id) ? 'fill-current' : ''}`} />
              {flaggedQuestions.has(currentQ.id) ? 'Belgilangan' : 'Belgilash'}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Question Text */}
          <p className="text-lg font-medium text-foreground leading-relaxed">
            {currentQ.text}
          </p>

          {/* Options */}
          <RadioGroup
            value={answers[currentQ.id]?.toString() || ''}
            onValueChange={(value) => handleAnswer(currentQ.id, parseInt(value))}
            className="space-y-3"
          >
            {currentQ.options.map((option, index) => (
              <div
                key={index}
                className={`flex items-center gap-3 p-4 rounded-xl border transition-all cursor-pointer ${
                  answers[currentQ.id] === index
                    ? 'border-primary bg-primary/5 ring-2 ring-primary/20'
                    : 'border-border hover:border-primary/50 hover:bg-muted/50'
                }`}
                onClick={() => handleAnswer(currentQ.id, index)}
              >
                <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                <Label
                  htmlFor={`option-${index}`}
                  className="flex-1 cursor-pointer text-foreground"
                >
                  <span className="font-medium text-primary mr-2">
                    {String.fromCharCode(65 + index)})
                  </span>
                  {option}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>
      </Card>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between gap-4">
        <Button
          variant="outline"
          onClick={() => goToQuestion(currentQuestion - 1)}
          disabled={currentQuestion === 0}
          className="gap-2"
        >
          <ChevronLeft className="h-4 w-4" />
          Oldingi
        </Button>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setShowExitDialog(true)}
            className="text-destructive"
          >
            Chiqish
          </Button>
          <Button
            variant="destructive"
            onClick={() => setShowSubmitDialog(true)}
            className="gap-2"
          >
            <Send className="h-4 w-4" />
            Yakunlash
          </Button>
        </div>

        <Button
          onClick={() => goToQuestion(currentQuestion + 1)}
          disabled={currentQuestion === test.questions.length - 1}
          className="gap-2"
        >
          Keyingi
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
