'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useToast } from '@/hooks/use-toast'
import { useTestStore, type Question, type TestCategory, type DifficultyLevel, CATEGORY_LABELS, DIFFICULTY_LABELS } from '@/store/testStore'
import { 
  Plus, 
  Trash2, 
  Sparkles, 
  Loader2,
  FileText,
  ListOrdered,
  GripVertical,
  CheckCircle2,
  Eye,
  Save,
  AlertCircle,
  Minus
} from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

// Generate unique ID
const generateId = () => Math.random().toString(36).substr(2, 9)

export function TestCreateForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const { addTest, updateTest, getTest } = useTestStore()
  
  // Check if editing existing test
  const editId = searchParams.get('editId')
  const isEditing = !!editId
  
  const [testName, setTestName] = useState('')
  const [description, setDescription] = useState('')
  const [timeLimit, setTimeLimit] = useState(0)
  const [category, setCategory] = useState<TestCategory>('boshqa')
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('orta')
  const [shuffleQuestions, setShuffleQuestions] = useState(true)
  const [showExplanations, setShowExplanations] = useState(true)
  const [passingScore, setPassingScore] = useState(60)
  const [questions, setQuestions] = useState<Question[]>([
    { id: generateId(), text: '', options: ['', '', '', ''], correctAnswer: 0 }
  ])
  const [isGenerating, setIsGenerating] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [showPreview, setShowPreview] = useState(false)
  const [aiTopic, setAiTopic] = useState('')
  const [aiQuestionCount, setAiQuestionCount] = useState(5)
  const [showAiDialog, setShowAiDialog] = useState(false)

  // Load existing test for editing
  useEffect(() => {
    if (editId) {
      const existingTest = getTest(editId)
      if (existingTest) {
        setTestName(existingTest.name)
        setDescription(existingTest.description || '')
        setTimeLimit(existingTest.timeLimit || 0)
        setCategory(existingTest.category || 'boshqa')
        setDifficulty(existingTest.difficulty || 'orta')
        setShuffleQuestions(existingTest.shuffleQuestions ?? true)
        setShowExplanations(existingTest.showExplanations ?? true)
        setPassingScore(existingTest.passingScore || 60)
        setQuestions(existingTest.questions)
      } else {
        toast({
          title: 'Test topilmadi',
          description: 'Tahrirlash uchun test topilmadi',
          variant: 'destructive',
        })
        router.push('/?view=tests')
      }
    }
  }, [editId, getTest, router, toast])

  // Calculate current step based on form completion
  const getCurrentStep = () => {
    if (!testName.trim()) return 1
    const hasValidQuestions = questions.some(q => q.text.trim() && q.options.filter(o => o.trim()).length >= 2)
    if (!hasValidQuestions) return 2
    return 3
  }
  const currentStep = getCurrentStep()

  // Add new question
  const addQuestion = () => {
    setQuestions([
      ...questions,
      { id: generateId(), text: '', options: ['', '', '', ''], correctAnswer: 0 }
    ])
    toast({
      title: 'Savol qo\'shildi',
      description: `${questions.length + 1}-savol qo'shildi`,
    })
  }

  // Remove question
  const removeQuestion = (id: string) => {
    if (questions.length > 1) {
      const removedIndex = questions.findIndex(q => q.id === id)
      setQuestions(questions.filter(q => q.id !== id))
      toast({
        title: 'Savol o\'chirildi',
        description: `${removedIndex + 1}-savol o'chirildi`,
        variant: 'destructive',
      })
    } else {
      toast({
        title: 'Kamida bitta savol bo\'lishi kerak',
        variant: 'destructive',
      })
    }
  }

  // Update question field
  const updateQuestion = (id: string, field: keyof Question, value: string | number | string[]) => {
    setQuestions(questions.map(q => 
      q.id === id ? { ...q, [field]: value } : q
    ))
  }

  // Update option text
  const updateOption = (questionId: string, optionIndex: number, value: string) => {
    setQuestions(questions.map(q => 
      q.id === questionId 
        ? { ...q, options: q.options.map((opt, i) => i === optionIndex ? value : opt) }
        : q
    ))
  }

  // Add more options to a question
  const addOption = (questionId: string) => {
    setQuestions(questions.map(q => 
      q.id === questionId && q.options.length < 6
        ? { ...q, options: [...q.options, ''] }
        : q
    ))
  }

  // Remove option from question
  const removeOption = (questionId: string, optionIndex: number) => {
    setQuestions(questions.map(q => {
      if (q.id === questionId && q.options.length > 2) {
        const newOptions = q.options.filter((_, i) => i !== optionIndex)
        const newCorrectAnswer = q.correctAnswer >= optionIndex && q.correctAnswer > 0
          ? q.correctAnswer - 1
          : q.correctAnswer
        return { ...q, options: newOptions, correctAnswer: newCorrectAnswer }
      }
      return q
    }))
  }

  // Generate questions with AI
  const generateWithAI = async () => {
    if (!aiTopic.trim()) {
      toast({
        title: 'Mavzu kiriting',
        description: 'AI savollar yaratishi uchun mavzu kiriting',
        variant: 'destructive',
      })
      return
    }

    setIsGenerating(true)
    
    try {
      const response = await fetch('/api/generate-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: aiTopic, count: aiQuestionCount }),
      })

      if (!response.ok) throw new Error('AI generation failed')

      const data = await response.json()
      
      if (data.questions && Array.isArray(data.questions)) {
        setQuestions(data.questions.map((q: { question: string; options: string[]; correct: number }) => ({
          id: generateId(),
          text: q.question,
          options: q.options,
          correctAnswer: q.correct,
        })))
        
        // Auto-fill test name from topic if empty
        if (!testName.trim()) {
          setTestName(aiTopic)
        }
        
        toast({
          title: 'Savollar yaratildi! ✅',
          description: `${data.questions.length} ta savol AI tomonidan yaratildi`,
        })
      }
    } catch (error) {
      // Fallback to demo questions
      const demoQuestions = Array.from({ length: aiQuestionCount }, (_, i) => ({
        id: generateId(),
        text: `${aiTopic} haqida ${i + 1}-savol?`,
        options: ['Birinchi javob', 'Ikkinchi javob', 'Uchinchi javob', 'To\'rtinchi javob'],
        correctAnswer: i % 4,
      }))
      
      setQuestions(demoQuestions)
      if (!testName.trim()) setTestName(aiTopic)
      
      toast({
        title: 'Demo savollar yaratildi',
        description: `${aiQuestionCount} ta demo savol yaratildi`,
      })
    } finally {
      setIsGenerating(false)
      setShowAiDialog(false)
      setAiTopic('')
    }
  }

  // Validate form
  const validateForm = () => {
    if (!testName.trim()) {
      toast({
        title: 'Test nomi kerak',
        description: 'Iltimos, test nomini kiriting',
        variant: 'destructive',
      })
      return false
    }

    const invalidQuestions = questions.filter(q => 
      !q.text.trim() || q.options.filter(o => o.trim()).length < 2
    )

    if (invalidQuestions.length > 0) {
      toast({
        title: 'Savollar to\'liq emas',
        description: 'Barcha savollar kamida 2 ta javob bilan to\'ldirilishi kerak',
        variant: 'destructive',
      })
      return false
    }

    return true
  }

  // Save test as draft
  const handleSave = async () => {
    if (!validateForm()) return

    setIsSaving(true)
    
    try {
      await new Promise(resolve => setTimeout(resolve, 500))
      
      if (isEditing && editId) {
        updateTest(editId, {
          name: testName,
          description,
          timeLimit,
          questions,
          status: 'draft',
        })
        toast({
          title: 'Test yangilandi! ✅',
          description: `"${testName}" testi saqlandi`,
        })
      } else {
        addTest({
          name: testName,
          description,
          timeLimit,
          questions,
          status: 'draft',
        })
        toast({
          title: 'Test saqlandi! ✅',
          description: `"${testName}" testi qoralama sifatida saqlandi`,
        })
      }

      router.push('/?view=tests')
    } catch (error) {
      toast({
        title: 'Xatolik yuz berdi',
        description: 'Testni saqlashda xatolik yuz berdi',
        variant: 'destructive',
      })
    } finally {
      setIsSaving(false)
    }
  }

  // Publish test
  const handlePublish = async () => {
    if (!validateForm()) return

    setIsSaving(true)
    
    try {
      await new Promise(resolve => setTimeout(resolve, 500))
      
      if (isEditing && editId) {
        updateTest(editId, {
          name: testName,
          description,
          timeLimit,
          questions,
          status: 'active',
        })
        toast({
          title: 'Test yangilandi! 🎉',
          description: `"${testName}" testi nashr etildi`,
        })
      } else {
        addTest({
          name: testName,
          description,
          timeLimit,
          questions,
          status: 'active',
        })
        toast({
          title: 'Test nashr etildi! 🎉',
          description: `"${testName}" testi endi faol`,
        })
      }

      router.push('/?view=tests')
    } catch (error) {
      toast({
        title: 'Xatolik yuz berdi',
        description: 'Testni nashr etishda xatolik yuz berdi',
        variant: 'destructive',
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">
            {isEditing ? 'Testni tahrirlash' : 'Test yaratish'}
          </h1>
          <p className="text-muted-foreground mt-1">
            {isEditing ? 'Test ma\'lumotlarini o\'zgartiring' : 'Yangi test yarating va savollar qo\'shing'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button 
            variant="outline" 
            className="gap-2"
            onClick={() => setShowAiDialog(true)}
          >
            <Sparkles className="h-4 w-4" />
            AI yordam
          </Button>
          <Button 
            variant="outline" 
            className="gap-2"
            onClick={() => setShowPreview(true)}
            disabled={!testName.trim() || questions.every(q => !q.text.trim())}
          >
            <Eye className="h-4 w-4" />
            Ko&apos;rish
          </Button>
          <Button 
            className="gap-2" 
            onClick={handlePublish}
            disabled={isSaving}
          >
            {isSaving ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <CheckCircle2 className="h-4 w-4" />
            )}
            {isEditing ? 'Yangilash' : 'Nashr etish'}
          </Button>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center gap-4">
        {[1, 2, 3].map((step) => (
          <div key={step} className="flex items-center gap-2">
            <div
              className={`h-8 w-8 rounded-full flex items-center justify-center text-sm font-medium transition-all ${
                currentStep >= step
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground'
              }`}
            >
              {currentStep > step ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : (
                step
              )}
            </div>
            {step < 3 && (
              <div className={`w-12 h-0.5 transition-all ${currentStep > step ? 'bg-primary' : 'bg-muted'}`} />
            )}
          </div>
        ))}
        <div className="ml-4 text-sm">
          {currentStep === 1 && <span className="text-muted-foreground">Test nomini kiriting</span>}
          {currentStep === 2 && <span className="text-muted-foreground">Savollar qo&apos;shing</span>}
          {currentStep === 3 && <span className="text-secondary font-medium">Tayyor! ✅</span>}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Test Info */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Test ma&apos;lumotlari
              </CardTitle>
              <CardDescription>Test nomi va tavsifini kiriting</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="testName">
                  Test nomi <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="testName"
                  placeholder="Masalan: Matematika - Algebra asoslari"
                  value={testName}
                  onChange={(e) => setTestName(e.target.value)}
                  className="h-12 rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Tavsif</Label>
                <Textarea
                  id="description"
                  placeholder="Test haqida qisqacha ma'lumot..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="min-h-[80px] rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="timeLimit">Vaqt limiti (daqiqada, 0 = cheksiz)</Label>
                <Input
                  id="timeLimit"
                  type="number"
                  min="0"
                  placeholder="Masalan: 30"
                  value={timeLimit || ''}
                  onChange={(e) => setTimeLimit(parseInt(e.target.value) || 0)}
                  className="h-12 rounded-xl"
                />
              </div>
            </CardContent>
          </Card>

          {/* Questions */}
          <Card className="bg-card border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg font-semibold flex items-center gap-2">
                    <ListOrdered className="h-5 w-5 text-primary" />
                    Savollar
                  </CardTitle>
                  <CardDescription>Test savollarini kiriting</CardDescription>
                </div>
                <Badge variant="secondary" className="text-sm px-3 py-1">
                  {questions.length} savol
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="max-h-[600px] pr-4">
                <div className="space-y-6">
                  {questions.map((question, qIndex) => (
                    <div 
                      key={question.id} 
                      className="space-y-4 pb-6 border-b border-border last:border-0"
                    >
                      {/* Question Header */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <GripVertical className="h-5 w-5 text-muted-foreground cursor-grab" />
                          <Badge 
                            variant="outline" 
                            className={`h-7 ${!question.text.trim() ? 'border-destructive text-destructive' : ''}`}
                          >
                            {qIndex + 1}-savol
                          </Badge>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeQuestion(question.id)}
                          disabled={questions.length === 1}
                          className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      {/* Question Text */}
                      <div className="space-y-2">
                        <Label>
                          Savol matni <span className="text-destructive">*</span>
                        </Label>
                        <Textarea
                          placeholder="Savolni kiriting..."
                          value={question.text}
                          onChange={(e) => updateQuestion(question.id, 'text', e.target.value)}
                          className="min-h-[60px] rounded-xl"
                        />
                      </div>

                      {/* Options */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label>
                            Javoblar <span className="text-destructive">*</span>
                          </Label>
                          {question.options.length < 6 && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => addOption(question.id)}
                              className="h-7 text-xs gap-1"
                            >
                              <Plus className="h-3 w-3" />
                              Javob qo&apos;shish
                            </Button>
                          )}
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {question.options.map((option, oIndex) => (
                            <div
                              key={oIndex}
                              className={`flex items-center gap-2 p-2 rounded-xl border transition-all cursor-pointer ${
                                question.correctAnswer === oIndex
                                  ? 'border-secondary bg-secondary/10 ring-2 ring-secondary/20'
                                  : 'border-border hover:border-primary/50'
                              }`}
                              onClick={() => updateQuestion(question.id, 'correctAnswer', oIndex)}
                            >
                              <div
                                className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold transition-all ${
                                  question.correctAnswer === oIndex
                                    ? 'bg-secondary text-secondary-foreground scale-110'
                                    : 'bg-muted text-muted-foreground'
                                }`}
                              >
                                {String.fromCharCode(65 + oIndex)}
                              </div>
                              <Input
                                placeholder={`${String.fromCharCode(65 + oIndex)} javob`}
                                value={option}
                                onChange={(e) => updateOption(question.id, oIndex, e.target.value)}
                                onClick={(e) => e.stopPropagation()}
                                className="h-9 border-0 focus-visible:ring-0 bg-transparent"
                              />
                              {question.options.length > 2 && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    removeOption(question.id, oIndex)
                                  }}
                                  className="h-7 w-7 shrink-0 opacity-50 hover:opacity-100 hover:bg-destructive/10 hover:text-destructive"
                                >
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              )}
                            </div>
                          ))}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          💡 To&apos;g&apos;ri javobni belgilash uchun kartochkaga bosing
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              <Button
                variant="outline"
                className="w-full mt-4 gap-2 h-12 rounded-xl border-dashed border-2 hover:border-primary hover:bg-primary/5 transition-all"
                onClick={addQuestion}
              >
                <Plus className="h-5 w-5" />
                Savol qo&apos;shish
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Summary */}
          <Card className="bg-card border-border sticky top-6">
            <CardHeader>
              <CardTitle className="text-lg font-semibold">Test xulosasi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Savollar soni</span>
                <Badge variant="secondary" className="text-sm">{questions.length}</Badge>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Vaqt limiti</span>
                <Badge variant="secondary" className="text-sm">
                  {timeLimit ? `${timeLimit} daqiqa` : 'Cheksiz'}
                </Badge>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Jami ball</span>
                <Badge variant="secondary" className="text-sm">{questions.length * 10} ball</Badge>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Status</span>
                <Badge 
                  variant="outline" 
                  className={`text-sm ${currentStep === 3 ? 'text-secondary border-secondary' : 'text-yellow-500 border-yellow-500'}`}
                >
                  {currentStep === 3 ? 'Tayyor ✅' : 'Qoralama'}
                </Badge>
              </div>

              <div className="pt-4 space-y-3">
                <Button 
                  className="w-full gap-2" 
                  onClick={handleSave}
                  disabled={isSaving || currentStep < 3}
                  variant="outline"
                >
                  <Save className="h-4 w-4" />
                  Qoralama saqlash
                </Button>
                <Button 
                  className="w-full gap-2" 
                  onClick={handlePublish}
                  disabled={isSaving || currentStep < 3}
                >
                  {isSaving ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="h-4 w-4" />
                  )}
                  {isEditing ? 'Yangilash' : 'Nashr etish'}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Tips */}
          <Card className="bg-muted/50 border-border">
            <CardContent className="p-4">
              <h4 className="font-medium text-sm mb-2">💡 Maslahatlar</h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Savolni aniq va tushunarli yozing</li>
                <li>• 4-5 ta javob varianti tavsiya etiladi</li>
                <li>• AI yordamida tez savollar yarating</li>
                <li>• Test nomini qisqa va chiroyli qiling</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* AI Dialog */}
      <Dialog open={showAiDialog} onOpenChange={setShowAiDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              AI yordamida savollar yaratish
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="aiTopic">Mavzu</Label>
              <Input
                id="aiTopic"
                placeholder="Masalan: Matematika algebra"
                value={aiTopic}
                onChange={(e) => setAiTopic(e.target.value)}
                className="h-12"
              />
            </div>
            
            <div className="space-y-2">
              <Label>Savollar soni</Label>
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setAiQuestionCount(Math.max(1, aiQuestionCount - 1))}
                  disabled={aiQuestionCount <= 1}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <div className="flex-1 text-center">
                  <span className="text-2xl font-bold text-foreground">{aiQuestionCount}</span>
                  <span className="text-muted-foreground ml-1">ta</span>
                </div>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setAiQuestionCount(Math.min(50, aiQuestionCount + 1))}
                  disabled={aiQuestionCount >= 50}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-center gap-2">
                <Input
                  type="range"
                  min="1"
                  max="50"
                  value={aiQuestionCount}
                  onChange={(e) => setAiQuestionCount(parseInt(e.target.value))}
                  className="flex-1"
                />
              </div>
              <p className="text-xs text-muted-foreground text-center">
                1 dan 50 gacha savol yaratish mumkin
              </p>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setShowAiDialog(false)}
              >
                Bekor qilish
              </Button>
              <Button
                className="flex-1 gap-2"
                onClick={generateWithAI}
                disabled={isGenerating || !aiTopic.trim()}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Yaratilmoqda...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    {aiQuestionCount} ta yaratish
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Test ko&apos;rish: {testName}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {description && (
              <p className="text-muted-foreground text-sm">{description}</p>
            )}
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>📝 {questions.length} savol</span>
              <span>⏱️ {timeLimit ? `${timeLimit} daqiqa` : 'Cheksiz'}</span>
              <span>🏆 {questions.length * 10} ball</span>
            </div>
            <Separator />
            {questions.map((question, index) => (
              <div key={question.id} className="space-y-3">
                <div className="flex items-start gap-3">
                  <Badge variant="outline" className="mt-1">{index + 1}</Badge>
                  <p className="font-medium">{question.text || 'Savol kiritilmagan'}</p>
                </div>
                <div className="grid grid-cols-2 gap-2 ml-8">
                  {question.options.map((option, oIndex) => (
                    <div
                      key={oIndex}
                      className={`p-2 rounded-lg text-sm ${
                        question.correctAnswer === oIndex
                          ? 'bg-secondary/20 text-secondary border border-secondary/30'
                          : 'bg-muted/50'
                      }`}
                    >
                      <span className="font-medium mr-2">{String.fromCharCode(65 + oIndex)})</span>
                      {option || 'Javob kiritilmagan'}
                      {question.correctAnswer === oIndex && (
                        <CheckCircle2 className="h-4 w-4 inline ml-2 text-secondary" />
                      )}
                    </div>
                  ))}
                </div>
                {index < questions.length - 1 && <Separator className="mt-4" />}
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
